<?php 

header("Location: ./home");exit();

?>