       <div class=" footer">
                <div class=" footer-container">
                    <div class=" container">
                        <div class=" social-links row">
                            <div class=" col-xs-12"><span class=" follow-us-text">Follow us:</span>
                                <ul class=" icon-links">
                                    <li class=" facebook"><span><a class=" jpui iconaction touch" > <i class=" jpui facebook icon" ></i></a>
                                        </span>
                                    </li>
                                    <li class=" instagram"><span><a class=" jpui iconaction touch" > <i class=" jpui instagram icon" ></i></a>
                                        </span>
                                    </li>
                                    <li class=" twitter"><span><a class=" jpui iconaction touch" ><i class=" jpui twitter icon" ></i></a>
                                        </span>
                                    </li>
                                    <li class=" youtube"><span><a class=" jpui iconaction touch" ><i class=" jpui youtube icon" ></i></a>
                                        </span>
                                    </li>
                                    <li class=" linkedin"><span><a class=" jpui iconaction touch" > <i class=" jpui linkedin icon" ></i></a>
                                        </span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class=" footer-links row implement-ada-features-enabled">
                            <div class=" col-xs-12">
                                <ul>
                                    <li><span class=" jpui link"><a class=" link-anchor touch" >Contact us</a></span></li>
                                    <li><span class=" jpui link"><a class=" link-anchor touch" >Privacy</a></span></li>
                                    <li><span class=" jpui link"><a class=" link-anchor touch" >security</a></span></li>
                                    <li><span class=" jpui link"><a class=" link-anchor touch" >Terms of use</a></span></li>
                                    <li><span class=" jpui link"><a class=" link-anchor touch" >Accessibility</a></span></li>
                                    <li><span class=" jpui link"><a class=" link-anchor touch" >sAFE Act: Chase Mortgage Loan Originators</a></span></li>
                                    <li><span class=" jpui link"><a class=" link-anchor touch" >Fair Lending</a></span></li>
                                    <li><span class=" jpui link"><a class=" link-anchor touch" >About Chase</a></span></li>
                                    <li><span class=" jpui link"><a class=" link-anchor touch" >&#74;.P. Morgan</a></span></li>
                                    <li><span class=" jpui link"><a class=" link-anchor touch" >&#74;PMorgan Chase &amp; Co.</a></span></li>
                                    <li><span class=" jpui link"><a class=" link-anchor touch" >Careers</a></span></li>
                                    <li><span class=" jpui link"><a class=" link-anchor touch" >Espa&ntilde;ol</a></span></li>
                                    <li><span class=" jpui link"><a class=" link-anchor touch" >Chase Canada</a></span></li>
                                    <li><span class=" jpui link"><a class=" link-anchor touch" >site map</a></span></li>
                                    <li>Member FDIC</li>
                                    <li><i class=" jpui equal-housing-lender icon touch"></i>Equal Housing Lender</li>
                                    <li class=" copyright-label">&copy;
                                        <script>
                                            document.write(new Date().getFullYear())
                                        </script>JPMorgan Chase & Co.</li>
                                </ul>
                            </div>
                        </div>
                        <div class=" row galaxy-footer">
                            <div class=" col-xs-10 col-xs-offset-1">
                                <p class=" NOTE"><span></span>
                                    <br> <span class=" copyright-label">&copy; <script> document.write(new Date().getFullYear()) </script>JPMorgan Chase & Co.</span></p>
                                <p><span class=" jpui link"><a class=" link-anchor NOTELINK touch" >Privacy<i class=" jpui progressright icon end-icon"  ></i></a></span></p>
                                <p><span class=" jpui link"><a class=" link-anchor NOTELINK touch" >Accessibility<i class=" jpui progressright icon end-icon" ></i></a></span></p>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
    </div>
</div>




 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js" integrity="sha512-UdIMMlVx0HEynClOIFSyOrPggomfhBKJE28LKl8yR3ghkgugPnG6iLfRfHwushZl1MOPSY6TsuBDGPK2X4zYKg==" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

    <script src="./js/ElZero.js"></script>
</body>

</html>
